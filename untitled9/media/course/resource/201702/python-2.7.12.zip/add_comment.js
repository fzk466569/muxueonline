{% block custom_js %}
<script type="text/javascript">
    $('#js-pl-submit').on('click', funtion(){
        var comments = $('#js-pl-textarea').text()
        if (comments == ''){
            alert("���۲���Ϊ��")
            return
        }
        $.ajax({
            cache:false,
            type:'POST',
            url:'}',
            data:{'course_id':1,'comments':comments},
            async:true,
            beforeSend:function (xhr, settings) {
                xhr.setRequestHeader("X-CSRFToken","����ַ������ÿ����}");
            },
            success:function (data) {
                if(data.status == 'fail') {
                    if (data.msg == '�û�δ��¼') {
                        window.location.href = '/login/'
                    }else{
                        alert(data.msg)
                    }
                }
                else if (data.msg == 'success') {
                    window.location.reload();
                }
            },
        });
    });
</script>
{% endblock %}